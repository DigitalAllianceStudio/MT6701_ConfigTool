//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by USB2SPI_FLASH_TEST.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_USB2SPI_FLASH_TEST_DIALOG   102
#define IDC_EDIT_HEX                    103
#define IDR_MAINFRAME                   128
#define IDC_EDIT_PAGE_ADDR              1000
#define IDC_STATIC_ADDR                 1001
#define IDC_BUTTON_PAGE_READ            1002
#define IDC_EDIT_USB_CONNECT_STATUS     1003
#define IDC_BUTTON_PAGE_WRITE           1004
#define IDC_BUTTON_PAGE_ERASE           1005
#define IDC_COMBO_FLASH_TYPE            1006
#define IDC_EDIT_FILE_TO_FLASH_PATH     1007
#define IDC_BUTTON_SELECT_FILE_PATH     1008
#define IDC_BUTTON_ERASE_FULL_CHIP      1009
#define IDC_BUTTON_FLASH_TO_FILE        1010
#define IDC_BUTTON_FILE_TO_FLASH        1011
#define IDC_BUTTON_PAGE_ERASE64K        1012
#define IDC_PROGRESS                    1013
#define IDC_CHECK_BEFOR_WRITE_ERZESE    1014
#define IDC_EDIT_FLASH_START_ADDR       1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
