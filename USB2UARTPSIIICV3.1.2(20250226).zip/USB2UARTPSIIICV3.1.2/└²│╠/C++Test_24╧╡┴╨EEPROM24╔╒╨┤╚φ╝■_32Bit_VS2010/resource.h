//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EEPROM24TEST.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EEPROM24TEST_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_COMBO_EEPRO_TYPE            1000
#define IDC_EDIT_MEM_SIZE               1002
#define IDC_EDIT_PAGE_SIZE              1003
#define IDC_EDIT_EEPROM_ADDR            1005
#define IDC_COMBO_A0_ADDR               1006
#define IDC_EDIT4                       1007
#define IDC_EDIT_HEX                    1008
#define IDC_EDIT_PAGE_STATE_ADDR        1008
#define IDC_EDIT_HEX_EE_ADDR            1009
#define IDC_EDIT_PAGE_STAT              1009
#define IDC_BUTTON_PAGE_READ            1010
#define IDC_BUTTON_PAGE_WRITE           1011
#define IDC_BUTTON_PAGE_DELETE          1012
#define IDC_EDIT_USB_CONNECT_STATUS     1013
#define IDC_EDIT_FILE_TO_EEPROM_PATH    1014
#define IDC_BUTTON_SELECT_FILE_PATH     1015
#define IDC_BUTTON_EEPROM_TO_FILE       1016
#define IDC_BUTTON_FILE_TO_EEPROM       1017
#define IDC_PROGRESS                    1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
